Style specifications and instructions for SyntaxFest 2021

These materials have been adapted form the materials for COLING-2020 proceedings
compiled by Derek F.  Wong, Yang Zhao and Liang Huang, which are, in turn,
COLING-2018 proceedings compiled by Xiaodan Zhu and Zhiyuan Liu, which are, in
turn, based on the instructions for COLING-2016 proceedings compiled by Hitoshi
Isahara and Masao Utiyama, which are, in turn, based on the instructions for
COLING-2014 proceedings compiled by Joachim Wagner, Liadh Kelly and Lorraine
Goeuriot, which are, in turn, based on the instructions for earlier ACL
proceedings, including those for ACL-2014 by Alexander Koller and Yusuke Miyao,
those for ACL-2012 by Maggie Li and Michael White, those for ACL-2010 by
Jing-Shing Chang and Philipp Koehn, those for ACL-2008 by Johanna D. Moore,
Simone Teufel, James Allan, and Sadaoki Furui, those for ACL-2005 by Hwee Tou Ng
and Kemal Oflazer, those for ACL-2002 by Eugene Charniak and Dekang Lin, and
earlier ACL and EACL formats.  Those versions were written by several people,
including John Chen, Henry S.  Thompson and Donald Walker. Additional elements
were taken from the formatting instructions of the International Joint
Conference on Artificial Intelligence.

* Contents

Makefile	Makefile for compling syntaxfest2021.tex in pdflatex
README.txt	This file
anthology.bib complete ACL anthology (16 Mar. 2021)
coling2020.bib	sample LaTeX bib file 
syntaxfest.bst		BibTeX `syntaxfest' style file
syntaxfest2021-word.docx	Microsoft Word file for SyntaxFest 2021
syntaxfest2021-libreoffice.odt	Libreoffice file for SyntaxFest 2021
syntaxfest2021.pdf	PDF file for SyntaxFest 2021
syntaxfest2021.sty	LaTeX style file for SyntaxFest 2021
syntaxfest2021.tex	LaTeX sample file for SyntaxFest 2021
